Dijkstra-Travel-Planner
=======================

Sanjay Nair
University of Florida: Spring 2013
Department of Computer Science and Engineering
COP3530: Data Structures and Algorithms
Project 4

A travel planner that calculates the optimal travel route by plane or bus based on Dijkstra's famous graph algorithm
